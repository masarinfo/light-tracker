import React from 'react';
import { Link } from 'react-router-dom';
import { Globe } from 'lucide-react';
import MarketPricesPage from '../MarketPricesPage';

export default function PublicMarketPage() {
  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-primary)]" dir="rtl">
      {/* Navigation */}
      <nav className="border-b border-white/10 bg-white/5 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Globe className="w-8 h-8 text-cyan-400" />
            <span className="text-xl font-black bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-500">
              Light Tracker V3
            </span>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-sm font-semibold text-gray-300 hover:text-white transition-colors">
              تسجيل الدخول
            </Link>
            <Link to="/register" className="px-4 py-2 rounded-xl bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 font-bold transition-all text-sm">
              ابدأ الآن
            </Link>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="mb-6">
          <h1 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            أسعار السوق المباشرة
          </h1>
          <p className="text-gray-400 mt-2">تابع أسعار العملات الرقمية والأسواق التقليدية لحظة بلحظة</p>
        </div>
        
        {/* Render the internal component but within our public shell */}
        <div className="bg-black/20 rounded-2xl border border-white/5 overflow-hidden">
            <MarketPricesPage />
        </div>
      </main>
    </div>
  );
}
