from apscheduler.schedulers.background import BackgroundScheduler
import logging
from services.binance_service import fetch_binance_prices

logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler()

def start_scheduler():
    # Run fetch_binance_prices every 10 seconds
    scheduler.add_job(fetch_binance_prices, 'interval', seconds=10, id='fetch_prices_job', replace_existing=True)
    scheduler.start()
    logger.info("Background scheduler started: Polling Binance every 10s")

def stop_scheduler():
    scheduler.shutdown()
