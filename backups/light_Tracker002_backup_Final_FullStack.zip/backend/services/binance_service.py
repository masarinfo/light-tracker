import requests
import logging

logger = logging.getLogger(__name__)

# In-memory cache for prices
LIVE_PRICES_CACHE = {
    "BTCUSDT": 60000.0,
    "ETHUSDT": 3000.0,
    "SOLUSDT": 100.0,
    "NEARUSDT": 5.0
}

def fetch_binance_prices():
    global LIVE_PRICES_CACHE
    try:
        response = requests.get("https://api.binance.com/api/v3/ticker/price", timeout=5)
        response.raise_for_status()
        data = response.json()
        
        # Update cache
        new_prices = {item['symbol']: float(item['price']) for item in data if item['symbol'].endswith('USDT')}
        LIVE_PRICES_CACHE.update(new_prices)
        
        logger.info(f"Successfully updated {len(new_prices)} prices from Binance.")
        
    except Exception as e:
        logger.error(f"Failed to fetch Binance prices: {str(e)}")

def get_cached_prices():
    return LIVE_PRICES_CACHE
