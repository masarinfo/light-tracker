from sqlalchemy import Column, Integer, String, Float, Boolean, JSON, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base

class Exchange(Base):
    __tablename__ = "exchanges"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(50), unique=True, index=True, nullable=False)
    maker_fee_pct = Column(Float, nullable=False, default=0.1)
    taker_fee_pct = Column(Float, nullable=False, default=0.1)
    use_discount_token = Column(Boolean, default=False)
    discount_token_symbol = Column(String(10), nullable=True)
    discount_pct = Column(Float, default=0.0)
    initial_cash_balance = Column(Float, nullable=False, default=0.0)
    
    strategies = relationship("Strategy", back_populates="exchange")
    portfolios = relationship("CoinPortfolio", back_populates="exchange")
    trades = relationship("Trade", back_populates="exchange")


class Strategy(Base):
    __tablename__ = "strategies"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(50), unique=True, index=True, nullable=False)
    category = Column(String(20), default="Short-Term") # Short-Term or Long-Term
    default_exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=True)
    default_order_type = Column(String(20), default="Limit")
    tp_rules = Column(JSON, nullable=False) # JSON array of TP rules
    sl_rules = Column(JSON, nullable=False) # JSON array of SL rules
    
    exchange = relationship("Exchange", back_populates="strategies")
    portfolios = relationship("CoinPortfolio", back_populates="strategy")
    trades = relationship("Trade", back_populates="strategy")


class CoinPortfolio(Base):
    __tablename__ = "coin_portfolios"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    symbol = Column(String(20), index=True, nullable=False)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=False)
    strategy_id = Column(Integer, ForeignKey("strategies.id"), nullable=False)
    total_quantity = Column(Float, default=0.0)
    average_cost = Column(Float, default=0.0)
    total_invested = Column(Float, default=0.0)
    realized_pnl = Column(Float, default=0.0)
    total_fees_paid = Column(Float, default=0.0)
    
    exchange = relationship("Exchange", back_populates="portfolios")
    strategy = relationship("Strategy", back_populates="portfolios")


class Trade(Base):
    __tablename__ = "trades"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    symbol = Column(String(20), index=True, nullable=False)
    strategy_id = Column(Integer, ForeignKey("strategies.id"), nullable=False)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=False)
    order_type = Column(String(20), nullable=False)
    entry_price = Column(Float, nullable=False)
    amount_usd = Column(Float, nullable=False)
    quantity = Column(Float, nullable=False)
    calculated_fee = Column(Float, nullable=False)
    status = Column(String(20), default="OPEN") # OPEN, PARTIALLY_CLOSED, CLOSED
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    exchange = relationship("Exchange", back_populates="trades")
    strategy = relationship("Strategy", back_populates="trades")
    targets = relationship("TradeTarget", back_populates="trade", cascade="all, delete-orphan")


class TradeTarget(Base):
    __tablename__ = "trade_targets"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    trade_id = Column(Integer, ForeignKey("trades.id", ondelete="CASCADE"), nullable=False)
    type = Column(String(5), nullable=False) # TP or SL
    stage = Column(Integer, nullable=False)
    target_price = Column(Float, nullable=False)
    quantity_to_sell = Column(Float, nullable=False)
    status = Column(String(20), default="PENDING") # PENDING or EXECUTED
    
    trade = relationship("Trade", back_populates="targets")


# We define the Users table as requested but we will not force auth right now
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
