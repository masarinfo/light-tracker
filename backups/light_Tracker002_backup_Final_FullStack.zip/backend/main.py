from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

import models
from database import engine
from routers import exchanges, strategies, trades
from scheduler import start_scheduler, stop_scheduler
from services.binance_service import get_cached_prices

# Setup logging
logging.basicConfig(level=logging.INFO)

# Create Database tables (empty DB as requested)
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Spot Trading Tracker Backend")

# Setup CORS for the React Frontend (default Vite port 5173)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup & Shutdown Events
@app.on_event("startup")
def on_startup():
    start_scheduler()

@app.on_event("shutdown")
def on_shutdown():
    stop_scheduler()

# Include Routers
app.include_router(exchanges.router)
app.include_router(strategies.router)
app.include_router(trades.router)

@app.get("/live-prices", tags=["prices"])
def live_prices():
    """
    Returns the cached Binance prices gathered by the background worker.
    """
    prices = get_cached_prices()
    return {
        "success": True,
        "source": "Backend (Binance API)",
        "prices": prices
    }
