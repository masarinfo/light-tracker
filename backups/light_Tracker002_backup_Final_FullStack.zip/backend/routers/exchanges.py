from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

import models, schemas
from database import get_db

router = APIRouter(
    prefix="/exchanges",
    tags=["exchanges"]
)

@router.get("/", response_model=List[schemas.ExchangeResponse])
def get_exchanges(db: Session = Depends(get_db)):
    return db.query(models.Exchange).all()

@router.post("/", response_model=schemas.ExchangeResponse)
def create_exchange(exchange: schemas.ExchangeCreate, db: Session = Depends(get_db)):
    db_exchange = models.Exchange(**exchange.model_dump())
    db.add(db_exchange)
    db.commit()
    db.refresh(db_exchange)
    return db_exchange

@router.put("/{exchange_id}", response_model=schemas.ExchangeResponse)
def update_exchange(exchange_id: int, exchange: schemas.ExchangeUpdate, db: Session = Depends(get_db)):
    db_exchange = db.query(models.Exchange).filter(models.Exchange.id == exchange_id).first()
    if not db_exchange:
        raise HTTPException(status_code=404, detail="Exchange not found")
    
    for key, value in exchange.model_dump().items():
        setattr(db_exchange, key, value)
        
    db.commit()
    db.refresh(db_exchange)
    return db_exchange

@router.delete("/{exchange_id}")
def delete_exchange(exchange_id: int, db: Session = Depends(get_db)):
    db_exchange = db.query(models.Exchange).filter(models.Exchange.id == exchange_id).first()
    if not db_exchange:
        raise HTTPException(status_code=404, detail="Exchange not found")
    
    db.delete(db_exchange)
    db.commit()
    return {"ok": True}
