from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

import models, schemas
from database import get_db

router = APIRouter(
    prefix="/trades",
    tags=["trades"]
)

@router.get("/", response_model=List[schemas.TradeResponse])
def get_trades(db: Session = Depends(get_db)):
    return db.query(models.Trade).order_by(models.Trade.created_at.desc()).all()

@router.post("/", response_model=schemas.TradeResponse)
def create_trade(trade: schemas.TradeCreate, db: Session = Depends(get_db)):
    db_trade = models.Trade(
        symbol=trade.symbol,
        strategy_id=trade.strategy_id,
        exchange_id=trade.exchange_id,
        order_type=trade.order_type,
        entry_price=trade.entry_price,
        amount_usd=trade.amount_usd,
        quantity=trade.quantity,
        calculated_fee=trade.calculated_fee,
        status=trade.status
    )
    db.add(db_trade)
    db.commit()
    db.refresh(db_trade)
    
    # Create associated targets
    for target_dict in trade.targets:
        db_target = models.TradeTarget(
            trade_id=db_trade.id,
            type=target_dict.get('type'),
            stage=target_dict.get('stage'),
            target_price=target_dict.get('targetPrice'),
            quantity_to_sell=target_dict.get('quantityToSell'),
            status=target_dict.get('status', 'PENDING')
        )
        db.add(db_target)
        
    db.commit()
    db.refresh(db_trade)
    return db_trade

@router.put("/{trade_id}", response_model=schemas.TradeResponse)
def update_trade(trade_id: int, trade: schemas.TradeUpdate, db: Session = Depends(get_db)):
    db_trade = db.query(models.Trade).filter(models.Trade.id == trade_id).first()
    if not db_trade:
        raise HTTPException(status_code=404, detail="Trade not found")
    
    db_trade.symbol = trade.symbol
    db_trade.strategy_id = trade.strategy_id
    db_trade.exchange_id = trade.exchange_id
    db_trade.order_type = trade.order_type
    db_trade.entry_price = trade.entry_price
    db_trade.amount_usd = trade.amount_usd
    db_trade.quantity = trade.quantity
    db_trade.calculated_fee = trade.calculated_fee
    db_trade.status = trade.status
    
    db.commit()
    db.refresh(db_trade)
    return db_trade

@router.delete("/{trade_id}")
def delete_trade(trade_id: int, db: Session = Depends(get_db)):
    db_trade = db.query(models.Trade).filter(models.Trade.id == trade_id).first()
    if not db_trade:
        raise HTTPException(status_code=404, detail="Trade not found")
    
    db.delete(db_trade)
    db.commit()
    return {"ok": True}
