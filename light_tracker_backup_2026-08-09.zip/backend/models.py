from sqlalchemy import Column, Integer, String, Float, Boolean, JSON, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_superadmin = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    exchanges = relationship("Exchange", back_populates="user", cascade="all, delete-orphan")
    strategies = relationship("Strategy", back_populates="user", cascade="all, delete-orphan")
    portfolios = relationship("CoinPortfolio", back_populates="user", cascade="all, delete-orphan")
    trades = relationship("Trade", back_populates="user", cascade="all, delete-orphan")


class Exchange(Base):
    __tablename__ = "exchanges"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(50), nullable=False)
    maker_fee_pct = Column(Float, nullable=False, default=0.1)
    taker_fee_pct = Column(Float, nullable=False, default=0.1)
    use_discount_token = Column(Boolean, default=False)
    discount_token_symbol = Column(String(10), nullable=True)
    discount_pct = Column(Float, default=0.0)
    initial_cash_balance = Column(Float, nullable=False, default=0.0)
    
    user = relationship("User", back_populates="exchanges")
    strategies = relationship("Strategy", back_populates="exchange")
    portfolios = relationship("CoinPortfolio", back_populates="exchange")
    trades = relationship("Trade", back_populates="exchange")
    wallet_transactions = relationship("WalletTransaction", foreign_keys="[WalletTransaction.exchange_id]", back_populates="exchange")

    # These properties provide safe fallback defaults, 
    # but the router computes the exact values before sending to UI.
    @property
    def total_deposits(self):
        return sum(t.amount for t in self.wallet_transactions if t.type == "DEPOSIT")

    @property
    def total_withdrawals(self):
        return sum(t.amount for t in self.wallet_transactions if t.type == "WITHDRAW")
        
    @property
    def total_transfers_in(self):
        return 0.0

    @property
    def total_transfers_out(self):
        return 0.0


class Strategy(Base):
    __tablename__ = "strategies"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(50), nullable=False)
    category = Column(String(20), default="Short-Term") # Short-Term or Long-Term
    default_exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=True)
    default_order_type = Column(String(20), default="Limit")
    tp_rules = Column(JSON, nullable=False) # JSON array of TP rules
    sl_rules = Column(JSON, nullable=False) # JSON array of SL rules
    
    user = relationship("User", back_populates="strategies")
    exchange = relationship("Exchange", back_populates="strategies")
    portfolios = relationship("CoinPortfolio", back_populates="strategy")
    trades = relationship("Trade", back_populates="strategy")


class CoinPortfolio(Base):
    __tablename__ = "coin_portfolios"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    symbol = Column(String(20), index=True, nullable=False)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=False)
    strategy_id = Column(Integer, ForeignKey("strategies.id"), nullable=False)
    total_quantity = Column(Float, default=0.0)
    average_cost = Column(Float, default=0.0)
    total_invested = Column(Float, default=0.0)
    realized_pnl = Column(Float, default=0.0)
    total_fees_paid = Column(Float, default=0.0)
    
    user = relationship("User", back_populates="portfolios")
    exchange = relationship("Exchange", back_populates="portfolios")
    strategy = relationship("Strategy", back_populates="portfolios")


class WalletTransaction(Base):
    __tablename__ = "wallet_transactions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=False)
    
    # DEPOSIT, WITHDRAW, TRANSFER
    type = Column(String(20), nullable=False)
    
    amount = Column(Float, nullable=False)
    fee = Column(Float, default=0.0)
    
    # For transfers, this tracks the destination exchange
    to_exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=True)
    
    notes = Column(String(500), nullable=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User")
    exchange = relationship("Exchange", foreign_keys=[exchange_id], back_populates="wallet_transactions")
    to_exchange = relationship("Exchange", foreign_keys=[to_exchange_id])


class Trade(Base):
    __tablename__ = "trades"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    symbol = Column(String(20), index=True, nullable=False)
    strategy_id = Column(Integer, ForeignKey("strategies.id"), nullable=False)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"), nullable=False)
    order_type = Column(String(20), nullable=False)
    entry_price = Column(Float, nullable=False)
    amount_usd = Column(Float, nullable=False)
    quantity = Column(Float, nullable=False)
    calculated_fee = Column(Float, nullable=False)
    status = Column(String(20), default="OPEN") # OPEN, PARTIALLY_CLOSED, CLOSED
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    user = relationship("User", back_populates="trades")
    exchange = relationship("Exchange", back_populates="trades")
    strategy = relationship("Strategy", back_populates="trades")
    targets = relationship("TradeTarget", back_populates="trade", cascade="all, delete-orphan")


class TradeTarget(Base):
    __tablename__ = "trade_targets"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    trade_id = Column(Integer, ForeignKey("trades.id", ondelete="CASCADE"), nullable=False)
    type = Column(String(5), nullable=False) # TP or SL
    stage = Column(Integer, nullable=False)
    target_price = Column(Float, nullable=False)
    quantity_to_sell = Column(Float, nullable=False)
    status = Column(String(20), default="PENDING") # PENDING, EXECUTED, CANCELLED
    
    trade = relationship("Trade", back_populates="targets")


class ActionLog(Base):
    __tablename__ = "action_logs"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True) # Nullable for system events or unknown logins
    action_type = Column(String(50), nullable=False, index=True) # e.g. LOGIN, CREATE_TRADE
    details = Column(String(500), nullable=True) # Additional details like "Symbol: BTCUSDT, Amount: 1000"
    ip_address = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    user = relationship("User")
