import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Lock, User, ArrowRight } from 'lucide-react';

export default function RegisterPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    const res = await register(username, password);
    if (res.success) {
      navigate('/dashboard');
    } else {
      setError(res.error || 'فشل إنشاء الحساب، ربما اسم المستخدم موجود مسبقاً');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0b0f19] text-white p-4" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 mb-2">
            Light Tracker
          </h1>
          <p className="text-gray-400">إنشاء حساب جديد</p>
        </div>

        <form onSubmit={handleSubmit} className="glass-panel p-8 rounded-2xl border border-white/10 space-y-6">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm font-bold text-center">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div className="relative">
              <input
                type="text"
                required
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="اسم المستخدم"
                className="w-full bg-black/20 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
              <User className="absolute right-3 top-3.5 w-5 h-5 text-gray-400" />
            </div>

            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="كلمة المرور"
                className="w-full bg-black/20 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
              <Lock className="absolute right-3 top-3.5 w-5 h-5 text-gray-400" />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            <span>إنشاء حساب</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <p className="text-center text-sm text-gray-400 mt-4">
            لديك حساب بالفعل؟{' '}
            <Link to="/login" className="text-cyan-400 hover:underline">
              تسجيل الدخول
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
