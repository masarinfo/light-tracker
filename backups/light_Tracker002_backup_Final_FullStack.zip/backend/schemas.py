from pydantic import BaseModel, Field
from typing import List, Optional, Any
from datetime import datetime

# --- Common / Generic ---

class TargetBase(BaseModel):
    stage: int
    gain_pct: Optional[float] = None
    loss_pct: Optional[float] = None
    sell_portion_pct: float

# --- Exchange Schemas ---

class ExchangeBase(BaseModel):
    name: str
    maker_fee_pct: float = 0.1
    taker_fee_pct: float = 0.1
    use_discount_token: bool = False
    discount_token_symbol: Optional[str] = None
    discount_pct: float = 0.0
    initial_cash_balance: float = 0.0

class ExchangeCreate(ExchangeBase):
    pass

class ExchangeUpdate(ExchangeBase):
    pass

class ExchangeResponse(ExchangeBase):
    id: int

    class Config:
        from_attributes = True


# --- Strategy Schemas ---

class StrategyBase(BaseModel):
    name: str
    category: str = "Short-Term"
    default_exchange_id: Optional[int] = None
    default_order_type: str = "Limit"
    tp_rules: List[TargetBase]
    sl_rules: List[TargetBase]

class StrategyCreate(StrategyBase):
    pass

class StrategyUpdate(StrategyBase):
    pass

class StrategyResponse(StrategyBase):
    id: int
    exchange: Optional[ExchangeResponse] = None

    class Config:
        from_attributes = True


# --- Trade Schemas ---

class TradeTargetResponse(BaseModel):
    id: int
    type: str
    stage: int
    target_price: float
    quantity_to_sell: float
    status: str

    class Config:
        from_attributes = True

class TradeBase(BaseModel):
    symbol: str
    strategy_id: int
    exchange_id: int
    order_type: str
    entry_price: float
    amount_usd: float
    quantity: float
    calculated_fee: float
    status: str = "OPEN"

class TradeCreate(TradeBase):
    targets: List[dict] # Accepting raw target dicts to save

class TradeUpdate(TradeBase):
    pass

class TradeResponse(TradeBase):
    id: int
    created_at: datetime
    targets: List[TradeTargetResponse] = []

    class Config:
        from_attributes = True
