import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations } from '../utils/i18n';
import { api } from '../api/client';
import { calculateCoinPortfolio, calculateOverviewMetrics } from '../utils/mathEngine';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [lang, setLang] = useState('ar');
  const [theme, setTheme] = useState('dark');
  const [activeScreen, setActiveScreen] = useState('overview');
  const [selectedStrategyId, setSelectedStrategyId] = useState(null);
  
  // Collapsible Sidebar State
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const [exchanges, setExchanges] = useState([]);
  const [strategies, setStrategies] = useState([]);
  const [trades, setTrades] = useState([]);

  const [livePrices, setLivePrices] = useState({});
  const [priceSource, setPriceSource] = useState('Connecting...');
  const [isFetchingPrices, setIsFetchingPrices] = useState(false);
  
  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [exData, stData, trData] = await Promise.all([
          api.getExchanges(),
          api.getStrategies(),
          api.getTrades()
        ]);
        setExchanges(exData);
        setStrategies(stData);
        
        // Enrich trades with strategy and exchange info for mathEngine
        const enrichedTrades = trData.map(tr => {
          const strat = stData.find(s => s.id === tr.strategy_id);
          const ex = exData.find(e => e.id === tr.exchange_id);
          return {
            ...tr,
            strategy_name: strat ? strat.name : 'Unknown',
            category: strat ? strat.category : 'Short-Term',
            exchange_name: ex ? ex.name : 'Unknown'
          };
        });
        setTrades(enrichedTrades);
      } catch (err) {
        console.error("Failed to load initial data from backend:", err);
      }
    };
    fetchData();
  }, []);

  // Sync theme with body element
  useEffect(() => {
    document.body.className = theme === 'light' ? 'theme-light' : 'theme-dark';
  }, [theme]);

  // Poll Backend for Binance Live Prices
  useEffect(() => {
    let isMounted = true;
    const updatePrices = async () => {
      setIsFetchingPrices(true);
      try {
        const res = await api.getLivePrices();
        if (isMounted) {
          if (res.success && res.prices) {
            setLivePrices((prev) => ({ ...prev, ...res.prices }));
          }
          setPriceSource(res.source);
        }
      } catch (err) {
        if (isMounted) {
          setPriceSource("Offline");
        }
      } finally {
        if (isMounted) setIsFetchingPrices(false);
      }
    };

    updatePrices();
    const interval = setInterval(updatePrices, 10000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Helper translation function
  const t = (key) => {
    return translations[lang]?.[key] || translations['ar']?.[key] || key;
  };

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => !prev);
  };

  // --- CRUD Wrappers ---

  // Add Exchange
  const addExchange = async (exchangeData) => {
    try {
      const newEx = await api.createExchange(exchangeData);
      setExchanges((prev) => [...prev, newEx]);
    } catch (err) {
      console.error("Failed to create exchange:", err);
      throw err;
    }
  };

  // Update Exchange
  const updateExchange = async (updatedExchange) => {
    try {
      const res = await api.updateExchange(updatedExchange.id, updatedExchange);
      setExchanges((prev) =>
        prev.map((ex) => (String(ex.id) === String(res.id) ? res : ex))
      );
    } catch (err) {
      console.error("Failed to update exchange:", err);
      throw err;
    }
  };

  // Add Strategy
  const addStrategy = async (strategyData) => {
    try {
      const newStrat = await api.createStrategy(strategyData);
      setStrategies((prev) => [...prev, newStrat]);
    } catch (err) {
      console.error("Failed to create strategy:", err);
      throw err;
    }
  };

  // Update Strategy
  const updateStrategy = async (updatedStrategy) => {
    try {
      const res = await api.updateStrategy(updatedStrategy.id, updatedStrategy);
      setStrategies((prev) =>
        prev.map((st) => (String(st.id) === String(res.id) ? res : st))
      );
    } catch (err) {
      console.error("Failed to update strategy:", err);
      throw err;
    }
  };

  // Add Trade
  const addTrade = async (tradeData) => {
    try {
      const newTrade = await api.createTrade(tradeData);
      
      // Enrich before adding to state
      const strat = strategies.find(s => s.id === newTrade.strategy_id);
      const ex = exchanges.find(e => e.id === newTrade.exchange_id);
      const enrichedTrade = {
        ...newTrade,
        strategy_name: strat ? strat.name : 'Unknown',
        category: strat ? strat.category : 'Short-Term',
        exchange_name: ex ? ex.name : 'Unknown'
      };

      setTrades((prev) => [enrichedTrade, ...prev]);
    } catch (err) {
      console.error("Failed to create trade:", err);
      throw err;
    }
  };

  // Update Trade
  const updateTrade = async (updatedTrade) => {
    try {
      const res = await api.updateTrade(updatedTrade.id, updatedTrade);
      
      const strat = strategies.find(s => s.id === res.strategy_id);
      const ex = exchanges.find(e => e.id === res.exchange_id);
      const enrichedTrade = {
        ...res,
        strategy_name: strat ? strat.name : 'Unknown',
        category: strat ? strat.category : 'Short-Term',
        exchange_name: ex ? ex.name : 'Unknown'
      };

      setTrades((prev) =>
        prev.map((tr) => (String(tr.id) === String(enrichedTrade.id) ? enrichedTrade : tr))
      );
    } catch (err) {
      console.error("Failed to update trade:", err);
      throw err;
    }
  };

  // Derived calculations
  const coinPortfolios = calculateCoinPortfolio({ trades, livePrices });
  const overviewMetrics = calculateOverviewMetrics({ exchanges, coinPortfolios });

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        toggleLanguage,
        theme,
        toggleTheme,
        t,
        activeScreen,
        setActiveScreen,
        selectedStrategyId,
        setSelectedStrategyId,
        isSidebarCollapsed,
        setIsSidebarCollapsed,
        toggleSidebar,
        exchanges,
        addExchange,
        updateExchange,
        strategies,
        addStrategy,
        updateStrategy,
        trades,
        addTrade,
        updateTrade,
        livePrices,
        priceSource,
        isFetchingPrices,
        coinPortfolios,
        overviewMetrics
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
