import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider, useApp } from './context/AppContext';

import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';

import ExchangeSetupPage from './pages/ExchangeSetupPage';
import StrategyFactoryPage from './pages/StrategyFactoryPage';
import CoinPortfolioPage from './pages/CoinPortfolioPage';
import TradeEntryPage from './pages/TradeEntryPage';
import TradesHistoryPage from './pages/TradesHistoryPage';
import OverviewDashboardPage from './pages/OverviewDashboardPage';
import MarketPricesPage from './pages/MarketPricesPage';
import ShortTermDashboardPage from './pages/ShortTermDashboardPage';
import LongTermDashboardPage from './pages/LongTermDashboardPage';
import StrategyComparisonPage from './pages/StrategyComparisonPage';
import StrategyDashboardPage from './pages/StrategyDashboardPage';
import SecurityPreviewPage from './pages/SecurityPreviewPage';
import SystemLogsPage from './pages/SystemLogsPage';
import UsersManagementPage from './pages/UsersManagementPage';
import WalletPage from './pages/WalletPage';

import LandingPage from './pages/public/LandingPage';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import PublicMarketPage from './pages/public/PublicMarketPage';

function PrivateAppWrapper() {
  const { activeScreen, lang } = useApp();
  
  const renderScreen = () => {
    if (activeScreen === 'exchange-setup') return <ExchangeSetupPage />;
    if (activeScreen === 'strategy-factory') return <StrategyFactoryPage />;
    if (activeScreen === 'coin-portfolio') return <CoinPortfolioPage />;
    if (activeScreen === 'trade-entry') return <TradeEntryPage />;
    if (activeScreen === 'trade-history') return <TradesHistoryPage />;
    if (activeScreen === 'market-prices') return <MarketPricesPage />;
    if (activeScreen === 'wallet') return <WalletPage />;
    if (activeScreen === 'system-logs') return <SystemLogsPage />;
    if (activeScreen === 'users-management') return <UsersManagementPage />;
    if (activeScreen === 'overview') return <OverviewDashboardPage />;
    if (activeScreen === 'short-term') return <ShortTermDashboardPage />;
    if (activeScreen === 'long-term') return <LongTermDashboardPage />;
    if (activeScreen === 'strategy-comparison') return <StrategyComparisonPage />;
    if (activeScreen.startsWith('strategy-')) return <StrategyDashboardPage />;
    if (activeScreen === 'security-preview') return <SecurityPreviewPage />;
    return <OverviewDashboardPage />;
  };

  const isRtl = lang === 'ar';

  return (
    <div dir={isRtl ? 'rtl' : 'ltr'} className="min-h-screen flex bg-[var(--bg-main)] text-[var(--text-primary)] transition-colors duration-300">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 overflow-y-auto">
          {renderScreen()}
        </main>
      </div>
    </div>
  );
}

function PrivateLayout() {
  const { user, isLoading } = useAuth();
  
  if (isLoading) return <div className="flex h-screen items-center justify-center text-white bg-slate-900">جاري التحميل...</div>;
  if (!user) return <Navigate to="/login" replace />;

  return <PrivateAppWrapper />;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/market" element={<PublicMarketPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/dashboard/*" element={<PrivateLayout />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
