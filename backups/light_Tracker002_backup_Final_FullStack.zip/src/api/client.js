const API_BASE_URL = 'http://127.0.0.1:8000';

async function request(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  const response = await fetch(url, { ...options, headers });
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.detail || `API request failed with status ${response.status}`);
  }
  return response.json();
}

export const api = {
  // Exchanges
  getExchanges: () => request('/exchanges/'),
  createExchange: (data) => request('/exchanges/', { method: 'POST', body: JSON.stringify(data) }),
  updateExchange: (id, data) => request(`/exchanges/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteExchange: (id) => request(`/exchanges/${id}`, { method: 'DELETE' }),

  // Strategies
  getStrategies: () => request('/strategies/'),
  createStrategy: (data) => request('/strategies/', { method: 'POST', body: JSON.stringify(data) }),
  updateStrategy: (id, data) => request(`/strategies/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteStrategy: (id) => request(`/strategies/${id}`, { method: 'DELETE' }),

  // Trades
  getTrades: () => request('/trades/'),
  createTrade: (data) => request('/trades/', { method: 'POST', body: JSON.stringify(data) }),
  updateTrade: (id, data) => request(`/trades/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteTrade: (id) => request(`/trades/${id}`, { method: 'DELETE' }),

  // Live Prices
  getLivePrices: () => request('/live-prices')
};
